package application;

public class DuplicateSongException extends Exception {

}
