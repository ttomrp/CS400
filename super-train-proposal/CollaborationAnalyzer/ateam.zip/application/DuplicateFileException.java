package application;

@SuppressWarnings("serial")
public class DuplicateFileException extends Exception {
}