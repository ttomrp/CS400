package application;

/**
 * This class defines the duplicate file exception
 * @author Adam Cook, Felix Lin, Jonathan McMahon, Tomas Perez, Matthias
 * Schmitz
 *
 */
@SuppressWarnings("serial")
public class DuplicateFileException extends Exception {
}